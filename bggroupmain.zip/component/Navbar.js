import Link from 'next/link'
import {
  AppBar,
  Toolbar,
  CssBaseline,
  Typography,
  makeStyles,
} from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  navlinks: {
    marginLeft: theme.spacing(10),
    display: "flex",
  },
 logo: {
    flexGrow: "1",
    cursor: "pointer",
  },
  link: {
    textDecoration: "none",
    color: "white",
    fontSize: "20px",
    marginLeft: theme.spacing(20),
    "&:hover": {
      color: "yellow",
      borderBottom: "1px solid white",
    },
  },
}));

const navList=[{id:1,name:"Home"},{id:2,name:"About Us"},{id:3,name:"Business Verticals"},{id:4,name:"Contact Us"}];

export default function navbar() {
  const classes = useStyles();
 return (
   <>
     <AppBar position="static">
        <CssBaseline />
        <Toolbar> {navList.map(nav=> (
          <Typography key={nav.id}>{nav.name}</Typography>
        ))} </Toolbar></AppBar>
    </>
    )
} 