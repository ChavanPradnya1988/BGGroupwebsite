"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./component/Navbar.js":
/*!*****************************!*\
  !*** ./component/Navbar.js ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ navbar; }
/* harmony export */ });
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "F:\\BGGroup\\bggroupmain\\component\\Navbar.js",
    _s = $RefreshSig$();

// import Link from 'next/link'




var useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.makeStyles)(function (theme) {
  return {
    navlinks: {
      marginLeft: theme.spacing(10),
      display: "flex"
    },
    logo: {
      flexGrow: "1",
      cursor: "pointer"
    },
    link: {
      textDecoration: "none",
      color: "white",
      fontSize: "20px",
      marginLeft: theme.spacing(20),
      "&:hover": {
        color: "yellow",
        borderBottom: "1px solid white"
      }
    }
  };
});
var navList = [{
  id: 1,
  name: "Home"
}, {
  id: 2,
  name: "About Us"
}, {
  id: 3,
  name: "Business Verticals"
}, {
  id: 4,
  name: "Contact Us"
}];
function navbar() {
  _s();

  var classes = useStyles();
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.AppBar, {
      position: "static",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.CssBaseline, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 5
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: classes.navlinks,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_router_dom__WEBPACK_IMPORTED_MODULE_2__.Link, {
          to: "/",
          className: classes.link,
          children: "Home"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 5
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 5
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 4
    }, this)
  }, void 0, false);
}

_s(navbar, "8g5FPXexvSEOsxdmU7HicukHGqY=", false, function () {
  return [useStyles];
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC5lNzFmNjk4OGQ1MzliOGZkOWJjZS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFPQTs7O0FBRUEsSUFBTU0sU0FBUyxHQUFHRiw2REFBVSxDQUFDLFVBQUNHLEtBQUQ7QUFBQSxTQUFZO0FBQ3ZDQyxJQUFBQSxRQUFRLEVBQUU7QUFDUkMsTUFBQUEsVUFBVSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBYyxFQUFkLENBREo7QUFFUkMsTUFBQUEsT0FBTyxFQUFFO0FBRkQsS0FENkI7QUFLeENDLElBQUFBLElBQUksRUFBRTtBQUNIQyxNQUFBQSxRQUFRLEVBQUUsR0FEUDtBQUVIQyxNQUFBQSxNQUFNLEVBQUU7QUFGTCxLQUxrQztBQVN2Q0MsSUFBQUEsSUFBSSxFQUFFO0FBQ0pDLE1BQUFBLGNBQWMsRUFBRSxNQURaO0FBRUpDLE1BQUFBLEtBQUssRUFBRSxPQUZIO0FBR0pDLE1BQUFBLFFBQVEsRUFBRSxNQUhOO0FBSUpULE1BQUFBLFVBQVUsRUFBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWMsRUFBZCxDQUpSO0FBS0osaUJBQVc7QUFDVE8sUUFBQUEsS0FBSyxFQUFFLFFBREU7QUFFVEUsUUFBQUEsWUFBWSxFQUFFO0FBRkw7QUFMUDtBQVRpQyxHQUFaO0FBQUEsQ0FBRCxDQUE1QjtBQXFCQSxJQUFNQyxPQUFPLEdBQUMsQ0FBQztBQUFDQyxFQUFBQSxFQUFFLEVBQUMsQ0FBSjtBQUFNQyxFQUFBQSxJQUFJLEVBQUM7QUFBWCxDQUFELEVBQW9CO0FBQUNELEVBQUFBLEVBQUUsRUFBQyxDQUFKO0FBQU1DLEVBQUFBLElBQUksRUFBQztBQUFYLENBQXBCLEVBQTJDO0FBQUNELEVBQUFBLEVBQUUsRUFBQyxDQUFKO0FBQU1DLEVBQUFBLElBQUksRUFBQztBQUFYLENBQTNDLEVBQTRFO0FBQUNELEVBQUFBLEVBQUUsRUFBQyxDQUFKO0FBQU1DLEVBQUFBLElBQUksRUFBQztBQUFYLENBQTVFLENBQWQ7QUFFZSxTQUFTQyxNQUFULEdBQWtCO0FBQUE7O0FBQy9CLE1BQU1DLE9BQU8sR0FBR2xCLFNBQVMsRUFBekI7QUFDRCxzQkFDRTtBQUFBLDJCQUVBLDhEQUFDLHFEQUFEO0FBQVEsY0FBUSxFQUFDLFFBQWpCO0FBQUEsOEJBQ0MsOERBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURELGVBRUM7QUFBSyxpQkFBUyxFQUFFa0IsT0FBTyxDQUFDaEIsUUFBeEI7QUFBQSwrQkFDQSw4REFBQyxrREFBRDtBQUFNLFlBQUUsRUFBQyxHQUFUO0FBQWEsbUJBQVMsRUFBRWdCLE9BQU8sQ0FBQ1QsSUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkEsbUJBREY7QUE0Q0E7O0dBOUN1QlE7VUFDTmpCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudC9OYXZiYXIuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQge1xyXG4gIEFwcEJhcixcclxuICBUb29sYmFyLFxyXG4gIENzc0Jhc2VsaW5lLFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgbWFrZVN0eWxlcyxcclxufSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICBuYXZsaW5rczoge1xyXG4gICAgbWFyZ2luTGVmdDogdGhlbWUuc3BhY2luZygxMCksXHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICB9LFxyXG4gbG9nbzoge1xyXG4gICAgZmxleEdyb3c6IFwiMVwiLFxyXG4gICAgY3Vyc29yOiBcInBvaW50ZXJcIixcclxuICB9LFxyXG4gIGxpbms6IHtcclxuICAgIHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIixcclxuICAgIGNvbG9yOiBcIndoaXRlXCIsXHJcbiAgICBmb250U2l6ZTogXCIyMHB4XCIsXHJcbiAgICBtYXJnaW5MZWZ0OiB0aGVtZS5zcGFjaW5nKDIwKSxcclxuICAgIFwiJjpob3ZlclwiOiB7XHJcbiAgICAgIGNvbG9yOiBcInllbGxvd1wiLFxyXG4gICAgICBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkIHdoaXRlXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmNvbnN0IG5hdkxpc3Q9W3tpZDoxLG5hbWU6XCJIb21lXCJ9LHtpZDoyLG5hbWU6XCJBYm91dCBVc1wifSx7aWQ6MyxuYW1lOlwiQnVzaW5lc3MgVmVydGljYWxzXCJ9LHtpZDo0LG5hbWU6XCJDb250YWN0IFVzXCJ9XTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIG5hdmJhcigpIHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiByZXR1cm4gKFxyXG4gICA8PlxyXG5cclxuICAgPEFwcEJhciBwb3NpdGlvbj1cInN0YXRpY1wiPiBcclxuICAgIDxDc3NCYXNlbGluZSAvPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMubmF2bGlua3N9PlxyXG4gICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmxpbmt9PlxyXG4gICAgICAgICAgICAgIEhvbWVcclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgey8qIDxUb29sYmFyPiB7bmF2TGlzdC5tYXAobmF2PT4gKFxyXG5cclxuXHJcblxyXG4gIDxUeXBvZ3JhcGh5IGtleT17bmF2LmlkfT57bmF2Lm5hbWV9PC9UeXBvZ3JhcGh5PlxyXG5cclxuXHJcbikpfSA8L1Rvb2xiYXI+ICovfVxyXG48L0FwcEJhcj5cclxuICB7LyogPE5hdmJhcj4gKi99XHJcbiAgey8qIDxDb250YWluZXI+XHJcbiAgICBcclxuICA8TGluayBjbGFzc05hbWU9XCJuYXZiYXItYnJhbmRcIiBocmVmPVwiL1wiPjxpbWcgY2xhc3NOYW1lPVwibmF2YmFyLWxvZ29cIiBzcmM9XCIvaW1hZ2VzL2dpcm1lX2xvZ28ucG5nXCIvPjwvTGluaz5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibmF2YmFyLW1lbnVcIj4gKi99XHJcbiAgICB7LyogPE5hdmJhci5Ub2dnbGUgYXJpYS1jb250cm9scz1cImJhc2ljLW5hdmJhci1uYXZcIiAvPlxyXG4gICAgPE5hdmJhci5Db2xsYXBzZSBpZD1cImJhc2ljLW5hdmJhci1uYXZcIj5cclxuICAgICAgPE5hdiBjbGFzc05hbWU9XCJtZS1hdXRvXCI+XHJcbiAgICAgICAgPE5hdi5MaW5rIGhyZWY9XCIvXCI+SG9tZTwvTmF2Lkxpbms+XHJcbiAgICAgICAgPE5hdi5MaW5rIGhyZWY9XCIvUHJvZHVjdGNvbnRlbnRcIj5Qcm9kdWN0czwvTmF2Lkxpbms+XHJcbiAgICAgICAgPE5hdi5MaW5rIGhyZWY9XCIvQWJvdXR1c2NvbnRlbnRcIj5BYm91dCA8L05hdi5MaW5rPlxyXG4gICAgICAgIDxOYXYuTGluayBocmVmPVwiL0luZnJhc3RydWN0dXJlY29udGVudFwiPkluZnJhc3RydWN0dXJlIDwvTmF2Lkxpbms+XHJcbiAgICAgICAgPE5hdi5MaW5rIGhyZWY9XCIvQ29udGFjdHVzY29udGVudFwiPkNvbnRhY3Q8L05hdi5MaW5rPlxyXG4gICAgICBcclxuICAgICAgICBcclxuICAgICAgICAgICAgPE5hdi5MaW5rIGNsYXNzTmFtZT1cInB4LTQgcHQtMyBmb290ZXItbGlzdC1pdGVtXCIgaHJlZj1cIi9maWxlcy9icm9jaHVyZS5wZGZcIj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZS1saWdodFwiIHR5cGU9XCJzdWJtaXRcIj5Eb3dubG9hZCBCcm9jaHVyZSA8L2J1dHRvbj48L05hdi5MaW5rPlxyXG4gICAgICAgICAgXHJcbiAgICAgIDwvTmF2PlxyXG4gICAgPC9OYXZiYXIuQ29sbGFwc2U+XHJcbiAgICA8L2Rpdj5cclxuICA8L0NvbnRhaW5lcj5cclxuPC9OYXZiYXI+ICovfVxyXG5cclxuPC8+XHJcbiApXHJcbn0iXSwibmFtZXMiOlsiQXBwQmFyIiwiVG9vbGJhciIsIkNzc0Jhc2VsaW5lIiwiVHlwb2dyYXBoeSIsIm1ha2VTdHlsZXMiLCJMaW5rIiwidXNlU3R5bGVzIiwidGhlbWUiLCJuYXZsaW5rcyIsIm1hcmdpbkxlZnQiLCJzcGFjaW5nIiwiZGlzcGxheSIsImxvZ28iLCJmbGV4R3JvdyIsImN1cnNvciIsImxpbmsiLCJ0ZXh0RGVjb3JhdGlvbiIsImNvbG9yIiwiZm9udFNpemUiLCJib3JkZXJCb3R0b20iLCJuYXZMaXN0IiwiaWQiLCJuYW1lIiwibmF2YmFyIiwiY2xhc3NlcyJdLCJzb3VyY2VSb290IjoiIn0=