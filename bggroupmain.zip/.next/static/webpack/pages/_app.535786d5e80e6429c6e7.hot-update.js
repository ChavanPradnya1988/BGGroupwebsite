"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./component/Navbar.js":
/*!*****************************!*\
  !*** ./component/Navbar.js ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ navbar; }
/* harmony export */ });
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _excluded = ["children", "value", "index"];

var _jsxFileName = "F:\\BGGroup\\bggroupmain\\component\\Navbar.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.makeStyles)(function (theme) {
  return {
    navlinks: {
      marginLeft: theme.spacing(10),
      display: "flex"
    },
    logo: {
      flexGrow: "1",
      cursor: "pointer"
    },
    link: {
      textDecoration: "none",
      color: "white",
      fontSize: "20px",
      marginLeft: theme.spacing(20),
      "&:hover": {
        color: "yellow",
        borderBottom: "1px solid white"
      }
    }
  };
});
var navList = [{
  id: 1,
  name: "Home"
}, {
  id: 2,
  name: "About Us"
}, {
  id: 3,
  name: "Business Verticals"
}, {
  id: 4,
  name: "Contact Us"
}];
function navbar() {
  _s();

  var classes = useStyles();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_3__.useState(0),
      _React$useState2 = (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__.default)(_React$useState, 2),
      value = _React$useState2[0],
      setValue = _React$useState2[1];

  var handleChange = function handleChange(_, newValue) {
    return setValue(newValue);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.CssBaseline, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.AppBar, {
      position: "static",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Toolbar, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
          size: "large",
          edge: "start",
          color: "inherit",
          sx: {
            mr: 2
          },
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.MenuIcon, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Typography, {
          variant: "h6",
          noWrap: true,
          component: "div",
          sx: {
            display: {
              xs: "none",
              sm: "block"
            }
          },
          children: "MUI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 49,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Box, {
          flexGrow: 1
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tabs, {
          value: value,
          onChange: handleChange,
          textColor: "inherit",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "One"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "Two"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "Three"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      index: value,
      onChangeIndex: setValue,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 0,
        children: "Item One"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 1,
        children: "Item Two"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 2,
        children: "Item Three"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(navbar, "BDkWVlEh8+DaKPHysXJ2gpEmtFI=", false, function () {
  return [useStyles];
});

function TabPanel(props) {
  var children = props.children,
      value = props.value,
      index = props.index,
      other = (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__.default)(props, _excluded);

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", _objectSpread(_objectSpread({
    role: "tabpanel",
    hidden: value !== index
  }, other), {}, {
    children: value === index && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Box, {
      sx: {
        p: 3
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Typography, {
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 9
    }, this)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 84,
    columnNumber: 5
  }, this);
}

_c = TabPanel;

var _c;

$RefreshReg$(_c, "TabPanel");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC41MzU3ODZkNWU4MGU2NDI5YzZlNy5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUErQjs7O0FBYS9CLElBQU1XLFNBQVMsR0FBR0QsNkRBQVUsQ0FBQyxVQUFDRSxLQUFEO0FBQUEsU0FBWTtBQUN2Q0MsSUFBQUEsUUFBUSxFQUFFO0FBQ1JDLE1BQUFBLFVBQVUsRUFBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWMsRUFBZCxDQURKO0FBRVJDLE1BQUFBLE9BQU8sRUFBRTtBQUZELEtBRDZCO0FBS3hDQyxJQUFBQSxJQUFJLEVBQUU7QUFDSEMsTUFBQUEsUUFBUSxFQUFFLEdBRFA7QUFFSEMsTUFBQUEsTUFBTSxFQUFFO0FBRkwsS0FMa0M7QUFTdkNDLElBQUFBLElBQUksRUFBRTtBQUNKQyxNQUFBQSxjQUFjLEVBQUUsTUFEWjtBQUVKQyxNQUFBQSxLQUFLLEVBQUUsT0FGSDtBQUdKQyxNQUFBQSxRQUFRLEVBQUUsTUFITjtBQUlKVCxNQUFBQSxVQUFVLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjLEVBQWQsQ0FKUjtBQUtKLGlCQUFXO0FBQ1RPLFFBQUFBLEtBQUssRUFBRSxRQURFO0FBRVRFLFFBQUFBLFlBQVksRUFBRTtBQUZMO0FBTFA7QUFUaUMsR0FBWjtBQUFBLENBQUQsQ0FBNUI7QUFxQkEsSUFBTUMsT0FBTyxHQUFDLENBQUM7QUFBQ0MsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBRCxFQUFvQjtBQUFDRCxFQUFBQSxFQUFFLEVBQUMsQ0FBSjtBQUFNQyxFQUFBQSxJQUFJLEVBQUM7QUFBWCxDQUFwQixFQUEyQztBQUFDRCxFQUFBQSxFQUFFLEVBQUMsQ0FBSjtBQUFNQyxFQUFBQSxJQUFJLEVBQUM7QUFBWCxDQUEzQyxFQUE0RTtBQUFDRCxFQUFBQSxFQUFFLEVBQUMsQ0FBSjtBQUFNQyxFQUFBQSxJQUFJLEVBQUM7QUFBWCxDQUE1RSxDQUFkO0FBRWUsU0FBU0MsTUFBVCxHQUFrQjtBQUFBOztBQUMvQixNQUFNQyxPQUFPLEdBQUdsQixTQUFTLEVBQXpCOztBQUNBLHdCQUEwQlgsMkNBQUEsQ0FBZSxDQUFmLENBQTFCO0FBQUE7QUFBQSxNQUFPK0IsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsTUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ0MsQ0FBRCxFQUFJQyxRQUFKO0FBQUEsV0FBaUJILFFBQVEsQ0FBQ0csUUFBRCxDQUF6QjtBQUFBLEdBQXJCOztBQUNELHNCQUNFO0FBQUEsNEJBQ0csOERBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURILGVBRUcsOERBQUMscURBQUQ7QUFBUSxjQUFRLEVBQUMsUUFBakI7QUFBQSw2QkFDRSw4REFBQyxzREFBRDtBQUFBLGdDQUNFLDhEQUFDLHlEQUFEO0FBQVksY0FBSSxFQUFDLE9BQWpCO0FBQXlCLGNBQUksRUFBQyxPQUE5QjtBQUFzQyxlQUFLLEVBQUMsU0FBNUM7QUFBc0QsWUFBRSxFQUFFO0FBQUVDLFlBQUFBLEVBQUUsRUFBRTtBQUFOLFdBQTFEO0FBQUEsaUNBQ0UsOERBQUMsdURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSw4REFBQyx5REFBRDtBQUNFLGlCQUFPLEVBQUMsSUFEVjtBQUVFLGdCQUFNLE1BRlI7QUFHRSxtQkFBUyxFQUFDLEtBSFo7QUFJRSxZQUFFLEVBQUU7QUFBRXBCLFlBQUFBLE9BQU8sRUFBRTtBQUFFcUIsY0FBQUEsRUFBRSxFQUFFLE1BQU47QUFBY0MsY0FBQUEsRUFBRSxFQUFFO0FBQWxCO0FBQVgsV0FKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKRixlQVlFLDhEQUFDLGtEQUFEO0FBQUssa0JBQVEsRUFBRTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkYsZUFhRSw4REFBQyxtREFBRDtBQUFNLGVBQUssRUFBRVAsS0FBYjtBQUFvQixrQkFBUSxFQUFFRSxZQUE5QjtBQUE0QyxtQkFBUyxFQUFDLFNBQXREO0FBQUEsa0NBQ0UsOERBQUMsa0RBQUQ7QUFBSyxpQkFBSyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFLDhEQUFDLGtEQUFEO0FBQUssaUJBQUssRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkYsZUFHRSw4REFBQyxrREFBRDtBQUFLLGlCQUFLLEVBQUM7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkgsZUF1Qkc7QUFBSyxXQUFLLEVBQUVGLEtBQVo7QUFBbUIsbUJBQWEsRUFBRUMsUUFBbEM7QUFBQSw4QkFDRSw4REFBQyxRQUFEO0FBQVUsYUFBSyxFQUFFRCxLQUFqQjtBQUF3QixhQUFLLEVBQUUsQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUlFLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVBLEtBQWpCO0FBQXdCLGFBQUssRUFBRSxDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpGLGVBT0UsOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRUEsS0FBakI7QUFBd0IsYUFBSyxFQUFFLENBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBdkJIO0FBQUEsa0JBREY7QUFxQ0E7O0dBekN1Qkg7VUFDTmpCOzs7QUEwQ2xCLFNBQVM0QixRQUFULENBQWtCQyxLQUFsQixFQUF5QjtBQUN2QixNQUFRQyxRQUFSLEdBQTZDRCxLQUE3QyxDQUFRQyxRQUFSO0FBQUEsTUFBa0JWLEtBQWxCLEdBQTZDUyxLQUE3QyxDQUFrQlQsS0FBbEI7QUFBQSxNQUF5QlcsS0FBekIsR0FBNkNGLEtBQTdDLENBQXlCRSxLQUF6QjtBQUFBLE1BQW1DQyxLQUFuQyxpSUFBNkNILEtBQTdDOztBQUVBLHNCQUNFO0FBQUssUUFBSSxFQUFDLFVBQVY7QUFBcUIsVUFBTSxFQUFFVCxLQUFLLEtBQUtXO0FBQXZDLEtBQWtEQyxLQUFsRDtBQUFBLGNBQ0daLEtBQUssS0FBS1csS0FBVixpQkFDQyw4REFBQyxrREFBRDtBQUFLLFFBQUUsRUFBRTtBQUFFRSxRQUFBQSxDQUFDLEVBQUU7QUFBTCxPQUFUO0FBQUEsNkJBQ0UsOERBQUMseURBQUQ7QUFBQSxrQkFBYUg7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVNEOztLQVpRRiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9jb21wb25lbnQvTmF2YmFyLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO2ltcG9ydCB7XHJcbiAgQXBwQmFyLFxyXG4gIEJveCxcclxuICBUb29sYmFyLFxyXG4gIEljb25CdXR0b24sXHJcbiAgQ3NzQmFzZWxpbmUsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBNZW51SWNvbixcclxuICBUYWJzLFxyXG4gIFRhYixcclxuICBtYWtlU3R5bGVzLFxyXG59IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgbmF2bGlua3M6IHtcclxuICAgIG1hcmdpbkxlZnQ6IHRoZW1lLnNwYWNpbmcoMTApLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgfSxcclxuIGxvZ286IHtcclxuICAgIGZsZXhHcm93OiBcIjFcIixcclxuICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXHJcbiAgfSxcclxuICBsaW5rOiB7XHJcbiAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXHJcbiAgICBjb2xvcjogXCJ3aGl0ZVwiLFxyXG4gICAgZm9udFNpemU6IFwiMjBweFwiLFxyXG4gICAgbWFyZ2luTGVmdDogdGhlbWUuc3BhY2luZygyMCksXHJcbiAgICBcIiY6aG92ZXJcIjoge1xyXG4gICAgICBjb2xvcjogXCJ5ZWxsb3dcIixcclxuICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCB3aGl0ZVwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5jb25zdCBuYXZMaXN0PVt7aWQ6MSxuYW1lOlwiSG9tZVwifSx7aWQ6MixuYW1lOlwiQWJvdXQgVXNcIn0se2lkOjMsbmFtZTpcIkJ1c2luZXNzIFZlcnRpY2Fsc1wifSx7aWQ6NCxuYW1lOlwiQ29udGFjdCBVc1wifV07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBuYXZiYXIoKSB7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gUmVhY3QudXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKF8sIG5ld1ZhbHVlKSA9PiBzZXRWYWx1ZShuZXdWYWx1ZSk7XHJcbiByZXR1cm4gKFxyXG4gICA8PlxyXG4gICAgICA8Q3NzQmFzZWxpbmUgLz5cclxuICAgICAgPEFwcEJhciBwb3NpdGlvbj1cInN0YXRpY1wiPlxyXG4gICAgICAgIDxUb29sYmFyPlxyXG4gICAgICAgICAgPEljb25CdXR0b24gc2l6ZT1cImxhcmdlXCIgZWRnZT1cInN0YXJ0XCIgY29sb3I9XCJpbmhlcml0XCIgc3g9e3sgbXI6IDIgfX0+XHJcbiAgICAgICAgICAgIDxNZW51SWNvbiAvPlxyXG4gICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgdmFyaWFudD1cImg2XCJcclxuICAgICAgICAgICAgbm9XcmFwXHJcbiAgICAgICAgICAgIGNvbXBvbmVudD1cImRpdlwiXHJcbiAgICAgICAgICAgIHN4PXt7IGRpc3BsYXk6IHsgeHM6IFwibm9uZVwiLCBzbTogXCJibG9ja1wiIH0gfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgTVVJXHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICA8Qm94IGZsZXhHcm93PXsxfSAvPlxyXG4gICAgICAgICAgPFRhYnMgdmFsdWU9e3ZhbHVlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSB0ZXh0Q29sb3I9XCJpbmhlcml0XCI+XHJcbiAgICAgICAgICAgIDxUYWIgbGFiZWw9XCJPbmVcIiAvPlxyXG4gICAgICAgICAgICA8VGFiIGxhYmVsPVwiVHdvXCIgLz5cclxuICAgICAgICAgICAgPFRhYiBsYWJlbD1cIlRocmVlXCIgLz5cclxuICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICA8L1Rvb2xiYXI+XHJcbiAgICAgIDwvQXBwQmFyPlxyXG4gICAgICA8ZGl2IGluZGV4PXt2YWx1ZX0gb25DaGFuZ2VJbmRleD17c2V0VmFsdWV9PlxyXG4gICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXswfT5cclxuICAgICAgICAgIEl0ZW0gT25lXHJcbiAgICAgICAgPC9UYWJQYW5lbD5cclxuICAgICAgICA8VGFiUGFuZWwgdmFsdWU9e3ZhbHVlfSBpbmRleD17MX0+XHJcbiAgICAgICAgICBJdGVtIFR3b1xyXG4gICAgICAgIDwvVGFiUGFuZWw+XHJcbiAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezJ9PlxyXG4gICAgICAgICAgSXRlbSBUaHJlZVxyXG4gICAgICAgIDwvVGFiUGFuZWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gVGFiUGFuZWwocHJvcHMpIHtcclxuICBjb25zdCB7IGNoaWxkcmVuLCB2YWx1ZSwgaW5kZXgsIC4uLm90aGVyIH0gPSBwcm9wcztcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgcm9sZT1cInRhYnBhbmVsXCIgaGlkZGVuPXt2YWx1ZSAhPT0gaW5kZXh9IHsuLi5vdGhlcn0+XHJcbiAgICAgIHt2YWx1ZSA9PT0gaW5kZXggJiYgKFxyXG4gICAgICAgIDxCb3ggc3g9e3sgcDogMyB9fT5cclxuICAgICAgICAgIDxUeXBvZ3JhcGh5PntjaGlsZHJlbn08L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuIClcclxufSJdLCJuYW1lcyI6WyJSZWFjdCIsIkFwcEJhciIsIkJveCIsIlRvb2xiYXIiLCJJY29uQnV0dG9uIiwiQ3NzQmFzZWxpbmUiLCJUeXBvZ3JhcGh5IiwiTWVudUljb24iLCJUYWJzIiwiVGFiIiwibWFrZVN0eWxlcyIsInVzZVN0eWxlcyIsInRoZW1lIiwibmF2bGlua3MiLCJtYXJnaW5MZWZ0Iiwic3BhY2luZyIsImRpc3BsYXkiLCJsb2dvIiwiZmxleEdyb3ciLCJjdXJzb3IiLCJsaW5rIiwidGV4dERlY29yYXRpb24iLCJjb2xvciIsImZvbnRTaXplIiwiYm9yZGVyQm90dG9tIiwibmF2TGlzdCIsImlkIiwibmFtZSIsIm5hdmJhciIsImNsYXNzZXMiLCJ1c2VTdGF0ZSIsInZhbHVlIiwic2V0VmFsdWUiLCJoYW5kbGVDaGFuZ2UiLCJfIiwibmV3VmFsdWUiLCJtciIsInhzIiwic20iLCJUYWJQYW5lbCIsInByb3BzIiwiY2hpbGRyZW4iLCJpbmRleCIsIm90aGVyIiwicCJdLCJzb3VyY2VSb290IjoiIn0=