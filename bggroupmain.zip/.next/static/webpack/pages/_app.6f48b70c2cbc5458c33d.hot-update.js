"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./component/Navbar.js":
/*!*****************************!*\
  !*** ./component/Navbar.js ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ navbar; }
/* harmony export */ });
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _excluded = ["children", "value", "index"];

var _jsxFileName = "F:\\BGGroup\\bggroupmain\\component\\Navbar.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.makeStyles)(function (theme) {
  return {
    navlinks: {
      marginLeft: theme.spacing(10),
      display: "flex"
    },
    logo: {
      flexGrow: "1",
      cursor: "pointer"
    },
    link: {
      textDecoration: "none",
      color: "white",
      fontSize: "20px",
      marginLeft: theme.spacing(20),
      "&:hover": {
        color: "yellow",
        borderBottom: "1px solid white"
      }
    }
  };
});
var navList = [{
  id: 1,
  name: "Home"
}, {
  id: 2,
  name: "About Us"
}, {
  id: 3,
  name: "Business Verticals"
}, {
  id: 4,
  name: "Contact Us"
}];
function navbar() {
  _s();

  var classes = useStyles();

  var _React$useState = React.useState(0),
      _React$useState2 = (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__.default)(_React$useState, 2),
      value = _React$useState2[0],
      setValue = _React$useState2[1];

  var handleChange = function handleChange(_, newValue) {
    return setValue(newValue);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.CssBaseline, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.AppBar, {
      position: "static",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Toolbar, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
          size: "large",
          edge: "start",
          color: "inherit",
          sx: {
            mr: 2
          },
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.MenuIcon, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Typography, {
          variant: "h6",
          noWrap: true,
          component: "div",
          sx: {
            display: {
              xs: "none",
              sm: "block"
            }
          },
          children: "MUI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Box, {
          flexGrow: 1
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tabs, {
          value: value,
          onChange: handleChange,
          textColor: "inherit",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "One"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "Two"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "Three"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      index: value,
      onChangeIndex: setValue,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 0,
        children: "Item One"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 1,
        children: "Item Two"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 2,
        children: "Item Three"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(navbar, "BDkWVlEh8+DaKPHysXJ2gpEmtFI=", false, function () {
  return [useStyles];
});

function TabPanel(props) {
  var children = props.children,
      value = props.value,
      index = props.index,
      other = (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__.default)(props, _excluded);

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", _objectSpread(_objectSpread({
    role: "tabpanel",
    hidden: value !== index
  }, other), {}, {
    children: value === index && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Box, {
      sx: {
        p: 3
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Typography, {
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 9
    }, this)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 85,
    columnNumber: 5
  }, this);
}

_c = TabPanel;

var _c;

$RefreshReg$(_c, "TabPanel");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC42ZjQ4YjcwYzJjYmM1NDU4YzMzZC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOzs7QUFhQSxJQUFNVyxTQUFTLEdBQUdELDZEQUFVLENBQUMsVUFBQ0UsS0FBRDtBQUFBLFNBQVk7QUFDdkNDLElBQUFBLFFBQVEsRUFBRTtBQUNSQyxNQUFBQSxVQUFVLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjLEVBQWQsQ0FESjtBQUVSQyxNQUFBQSxPQUFPLEVBQUU7QUFGRCxLQUQ2QjtBQUt4Q0MsSUFBQUEsSUFBSSxFQUFFO0FBQ0hDLE1BQUFBLFFBQVEsRUFBRSxHQURQO0FBRUhDLE1BQUFBLE1BQU0sRUFBRTtBQUZMLEtBTGtDO0FBU3ZDQyxJQUFBQSxJQUFJLEVBQUU7QUFDSkMsTUFBQUEsY0FBYyxFQUFFLE1BRFo7QUFFSkMsTUFBQUEsS0FBSyxFQUFFLE9BRkg7QUFHSkMsTUFBQUEsUUFBUSxFQUFFLE1BSE47QUFJSlQsTUFBQUEsVUFBVSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBYyxFQUFkLENBSlI7QUFLSixpQkFBVztBQUNUTyxRQUFBQSxLQUFLLEVBQUUsUUFERTtBQUVURSxRQUFBQSxZQUFZLEVBQUU7QUFGTDtBQUxQO0FBVGlDLEdBQVo7QUFBQSxDQUFELENBQTVCO0FBcUJBLElBQU1DLE9BQU8sR0FBQyxDQUFDO0FBQUNDLEVBQUFBLEVBQUUsRUFBQyxDQUFKO0FBQU1DLEVBQUFBLElBQUksRUFBQztBQUFYLENBQUQsRUFBb0I7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBcEIsRUFBMkM7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBM0MsRUFBNEU7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBNUUsQ0FBZDtBQUVlLFNBQVNDLE1BQVQsR0FBa0I7QUFBQTs7QUFDL0IsTUFBTUMsT0FBTyxHQUFHbEIsU0FBUyxFQUF6Qjs7QUFDQSx3QkFBMEJtQixLQUFLLENBQUNDLFFBQU4sQ0FBZSxDQUFmLENBQTFCO0FBQUE7QUFBQSxNQUFPQyxLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxDQUFELEVBQUlDLFFBQUo7QUFBQSxXQUFpQkgsUUFBUSxDQUFDRyxRQUFELENBQXpCO0FBQUEsR0FBckI7O0FBQ0Qsc0JBQ0U7QUFBQSw0QkFDRyw4REFBQywwREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREgsZUFFRyw4REFBQyxxREFBRDtBQUFRLGNBQVEsRUFBQyxRQUFqQjtBQUFBLDZCQUNFLDhEQUFDLHNEQUFEO0FBQUEsZ0NBQ0UsOERBQUMseURBQUQ7QUFBWSxjQUFJLEVBQUMsT0FBakI7QUFBeUIsY0FBSSxFQUFDLE9BQTlCO0FBQXNDLGVBQUssRUFBQyxTQUE1QztBQUFzRCxZQUFFLEVBQUU7QUFBRUMsWUFBQUEsRUFBRSxFQUFFO0FBQU4sV0FBMUQ7QUFBQSxpQ0FDRSw4REFBQyx1REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUlFLDhEQUFDLHlEQUFEO0FBQ0UsaUJBQU8sRUFBQyxJQURWO0FBRUUsZ0JBQU0sTUFGUjtBQUdFLG1CQUFTLEVBQUMsS0FIWjtBQUlFLFlBQUUsRUFBRTtBQUFFckIsWUFBQUEsT0FBTyxFQUFFO0FBQUVzQixjQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxjQUFBQSxFQUFFLEVBQUU7QUFBbEI7QUFBWCxXQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGLGVBWUUsOERBQUMsa0RBQUQ7QUFBSyxrQkFBUSxFQUFFO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFaRixlQWFFLDhEQUFDLG1EQUFEO0FBQU0sZUFBSyxFQUFFUCxLQUFiO0FBQW9CLGtCQUFRLEVBQUVFLFlBQTlCO0FBQTRDLG1CQUFTLEVBQUMsU0FBdEQ7QUFBQSxrQ0FDRSw4REFBQyxrREFBRDtBQUFLLGlCQUFLLEVBQUM7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBRUUsOERBQUMsa0RBQUQ7QUFBSyxpQkFBSyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRixlQUdFLDhEQUFDLGtEQUFEO0FBQUssaUJBQUssRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGSCxlQXVCRztBQUFLLFdBQUssRUFBRUYsS0FBWjtBQUFtQixtQkFBYSxFQUFFQyxRQUFsQztBQUFBLDhCQUNFLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVELEtBQWpCO0FBQXdCLGFBQUssRUFBRSxDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBSUUsOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRUEsS0FBakI7QUFBd0IsYUFBSyxFQUFFLENBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkYsZUFPRSw4REFBQyxRQUFEO0FBQVUsYUFBSyxFQUFFQSxLQUFqQjtBQUF3QixhQUFLLEVBQUUsQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF2Qkg7QUFBQSxrQkFERjtBQXFDQTs7R0F6Q3VCSjtVQUNOakI7OztBQTBDbEIsU0FBUzZCLFFBQVQsQ0FBa0JDLEtBQWxCLEVBQXlCO0FBQ3ZCLE1BQVFDLFFBQVIsR0FBNkNELEtBQTdDLENBQVFDLFFBQVI7QUFBQSxNQUFrQlYsS0FBbEIsR0FBNkNTLEtBQTdDLENBQWtCVCxLQUFsQjtBQUFBLE1BQXlCVyxLQUF6QixHQUE2Q0YsS0FBN0MsQ0FBeUJFLEtBQXpCO0FBQUEsTUFBbUNDLEtBQW5DLGlJQUE2Q0gsS0FBN0M7O0FBRUEsc0JBQ0U7QUFBSyxRQUFJLEVBQUMsVUFBVjtBQUFxQixVQUFNLEVBQUVULEtBQUssS0FBS1c7QUFBdkMsS0FBa0RDLEtBQWxEO0FBQUEsY0FDR1osS0FBSyxLQUFLVyxLQUFWLGlCQUNDLDhEQUFDLGtEQUFEO0FBQUssUUFBRSxFQUFFO0FBQUVFLFFBQUFBLENBQUMsRUFBRTtBQUFMLE9BQVQ7QUFBQSw2QkFDRSw4REFBQyx5REFBRDtBQUFBLGtCQUFhSDtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBU0Q7O0tBWlFGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudC9OYXZiYXIuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQge1xyXG4gIEFwcEJhcixcclxuICBCb3gsXHJcbiAgVG9vbGJhcixcclxuICBJY29uQnV0dG9uLFxyXG4gIENzc0Jhc2VsaW5lLFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgTWVudUljb24sXHJcbiAgVGFicyxcclxuICBUYWIsXHJcbiAgbWFrZVN0eWxlcyxcclxufSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIG5hdmxpbmtzOiB7XHJcbiAgICBtYXJnaW5MZWZ0OiB0aGVtZS5zcGFjaW5nKDEwKSxcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gIH0sXHJcbiBsb2dvOiB7XHJcbiAgICBmbGV4R3JvdzogXCIxXCIsXHJcbiAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gIH0sXHJcbiAgbGluazoge1xyXG4gICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxyXG4gICAgY29sb3I6IFwid2hpdGVcIixcclxuICAgIGZvbnRTaXplOiBcIjIwcHhcIixcclxuICAgIG1hcmdpbkxlZnQ6IHRoZW1lLnNwYWNpbmcoMjApLFxyXG4gICAgXCImOmhvdmVyXCI6IHtcclxuICAgICAgY29sb3I6IFwieWVsbG93XCIsXHJcbiAgICAgIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgd2hpdGVcIixcclxuICAgIH0sXHJcbiAgfSxcclxufSkpO1xyXG5cclxuY29uc3QgbmF2TGlzdD1be2lkOjEsbmFtZTpcIkhvbWVcIn0se2lkOjIsbmFtZTpcIkFib3V0IFVzXCJ9LHtpZDozLG5hbWU6XCJCdXNpbmVzcyBWZXJ0aWNhbHNcIn0se2lkOjQsbmFtZTpcIkNvbnRhY3QgVXNcIn1dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbmF2YmFyKCkge1xyXG4gIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChfLCBuZXdWYWx1ZSkgPT4gc2V0VmFsdWUobmV3VmFsdWUpO1xyXG4gcmV0dXJuIChcclxuICAgPD5cclxuICAgICAgPENzc0Jhc2VsaW5lIC8+XHJcbiAgICAgIDxBcHBCYXIgcG9zaXRpb249XCJzdGF0aWNcIj5cclxuICAgICAgICA8VG9vbGJhcj5cclxuICAgICAgICAgIDxJY29uQnV0dG9uIHNpemU9XCJsYXJnZVwiIGVkZ2U9XCJzdGFydFwiIGNvbG9yPVwiaW5oZXJpdFwiIHN4PXt7IG1yOiAyIH19PlxyXG4gICAgICAgICAgICA8TWVudUljb24gLz5cclxuICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJoNlwiXHJcbiAgICAgICAgICAgIG5vV3JhcFxyXG4gICAgICAgICAgICBjb21wb25lbnQ9XCJkaXZcIlxyXG4gICAgICAgICAgICBzeD17eyBkaXNwbGF5OiB7IHhzOiBcIm5vbmVcIiwgc206IFwiYmxvY2tcIiB9IH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIE1VSVxyXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPEJveCBmbGV4R3Jvdz17MX0gLz5cclxuICAgICAgICAgIDxUYWJzIHZhbHVlPXt2YWx1ZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gdGV4dENvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICA8VGFiIGxhYmVsPVwiT25lXCIgLz5cclxuICAgICAgICAgICAgPFRhYiBsYWJlbD1cIlR3b1wiIC8+XHJcbiAgICAgICAgICAgIDxUYWIgbGFiZWw9XCJUaHJlZVwiIC8+XHJcbiAgICAgICAgICA8L1RhYnM+XHJcbiAgICAgICAgPC9Ub29sYmFyPlxyXG4gICAgICA8L0FwcEJhcj5cclxuICAgICAgPGRpdiBpbmRleD17dmFsdWV9IG9uQ2hhbmdlSW5kZXg9e3NldFZhbHVlfT5cclxuICAgICAgICA8VGFiUGFuZWwgdmFsdWU9e3ZhbHVlfSBpbmRleD17MH0+XHJcbiAgICAgICAgICBJdGVtIE9uZVxyXG4gICAgICAgIDwvVGFiUGFuZWw+XHJcbiAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezF9PlxyXG4gICAgICAgICAgSXRlbSBUd29cclxuICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXsyfT5cclxuICAgICAgICAgIEl0ZW0gVGhyZWVcclxuICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFRhYlBhbmVsKHByb3BzKSB7XHJcbiAgY29uc3QgeyBjaGlsZHJlbiwgdmFsdWUsIGluZGV4LCAuLi5vdGhlciB9ID0gcHJvcHM7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHJvbGU9XCJ0YWJwYW5lbFwiIGhpZGRlbj17dmFsdWUgIT09IGluZGV4fSB7Li4ub3RoZXJ9PlxyXG4gICAgICB7dmFsdWUgPT09IGluZGV4ICYmIChcclxuICAgICAgICA8Qm94IHN4PXt7IHA6IDMgfX0+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeT57Y2hpbGRyZW59PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiApXHJcbn0iXSwibmFtZXMiOlsiTGluayIsIkFwcEJhciIsIkJveCIsIlRvb2xiYXIiLCJJY29uQnV0dG9uIiwiQ3NzQmFzZWxpbmUiLCJUeXBvZ3JhcGh5IiwiTWVudUljb24iLCJUYWJzIiwiVGFiIiwibWFrZVN0eWxlcyIsInVzZVN0eWxlcyIsInRoZW1lIiwibmF2bGlua3MiLCJtYXJnaW5MZWZ0Iiwic3BhY2luZyIsImRpc3BsYXkiLCJsb2dvIiwiZmxleEdyb3ciLCJjdXJzb3IiLCJsaW5rIiwidGV4dERlY29yYXRpb24iLCJjb2xvciIsImZvbnRTaXplIiwiYm9yZGVyQm90dG9tIiwibmF2TGlzdCIsImlkIiwibmFtZSIsIm5hdmJhciIsImNsYXNzZXMiLCJSZWFjdCIsInVzZVN0YXRlIiwidmFsdWUiLCJzZXRWYWx1ZSIsImhhbmRsZUNoYW5nZSIsIl8iLCJuZXdWYWx1ZSIsIm1yIiwieHMiLCJzbSIsIlRhYlBhbmVsIiwicHJvcHMiLCJjaGlsZHJlbiIsImluZGV4Iiwib3RoZXIiLCJwIl0sInNvdXJjZVJvb3QiOiIifQ==