"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./component/Navbar.js":
/*!*****************************!*\
  !*** ./component/Navbar.js ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ navbar; }
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "F:\\BGGroup\\bggroupmain\\component\\Navbar.js",
    _s = $RefreshSig$();





var useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.makeStyles)(function (theme) {
  return {
    navlinks: {
      marginLeft: theme.spacing(10),
      display: "flex"
    },
    logo: {
      flexGrow: "1",
      cursor: "pointer"
    },
    link: {
      textDecoration: "none",
      color: "white",
      fontSize: "20px",
      marginLeft: theme.spacing(20),
      "&:hover": {
        color: "yellow",
        borderBottom: "1px solid white"
      }
    }
  };
});
var navList = [{
  id: 1,
  name: "Home"
}, {
  id: 2,
  name: "About Us"
}, {
  id: 3,
  name: "Business Verticals"
}, {
  id: 4,
  name: "Contact Us"
}];
function navbar() {
  _s();

  var _this = this;

  var classes = useStyles();
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.AppBar, {
      position: "static",
      children: ["  ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.CssBaseline, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 32
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Toolbar, {
        children: [" ", navList.map(function (nav) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, {
            children: nav.name
          }, nav.id, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 3
          }, _this);
        }), " "]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 47
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 4
    }, this)
  }, void 0, false);
}

_s(navbar, "8g5FPXexvSEOsxdmU7HicukHGqY=", false, function () {
  return [useStyles];
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC4yZjgzMjA1N2E2ZWI4Mzc5MTc4MS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOzs7QUFRQSxJQUFNTSxTQUFTLEdBQUdELDZEQUFVLENBQUMsVUFBQ0UsS0FBRDtBQUFBLFNBQVk7QUFDdkNDLElBQUFBLFFBQVEsRUFBRTtBQUNSQyxNQUFBQSxVQUFVLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjLEVBQWQsQ0FESjtBQUVSQyxNQUFBQSxPQUFPLEVBQUU7QUFGRCxLQUQ2QjtBQUt4Q0MsSUFBQUEsSUFBSSxFQUFFO0FBQ0hDLE1BQUFBLFFBQVEsRUFBRSxHQURQO0FBRUhDLE1BQUFBLE1BQU0sRUFBRTtBQUZMLEtBTGtDO0FBU3ZDQyxJQUFBQSxJQUFJLEVBQUU7QUFDSkMsTUFBQUEsY0FBYyxFQUFFLE1BRFo7QUFFSkMsTUFBQUEsS0FBSyxFQUFFLE9BRkg7QUFHSkMsTUFBQUEsUUFBUSxFQUFFLE1BSE47QUFJSlQsTUFBQUEsVUFBVSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBYyxFQUFkLENBSlI7QUFLSixpQkFBVztBQUNUTyxRQUFBQSxLQUFLLEVBQUUsUUFERTtBQUVURSxRQUFBQSxZQUFZLEVBQUU7QUFGTDtBQUxQO0FBVGlDLEdBQVo7QUFBQSxDQUFELENBQTVCO0FBcUJBLElBQU1DLE9BQU8sR0FBQyxDQUFDO0FBQUNDLEVBQUFBLEVBQUUsRUFBQyxDQUFKO0FBQU1DLEVBQUFBLElBQUksRUFBQztBQUFYLENBQUQsRUFBb0I7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBcEIsRUFBMkM7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBM0MsRUFBNEU7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBNUUsQ0FBZDtBQUVlLFNBQVNDLE1BQVQsR0FBa0I7QUFBQTs7QUFBQTs7QUFDL0IsTUFBTUMsT0FBTyxHQUFHbEIsU0FBUyxFQUF6QjtBQUNELHNCQUNFO0FBQUEsMkJBRUEsOERBQUMscURBQUQ7QUFBUSxjQUFRLEVBQUMsUUFBakI7QUFBQSxvQ0FBNEIsOERBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUE1QixlQUEyQyw4REFBQyxzREFBRDtBQUFBLHdCQUFXYyxPQUFPLENBQUNLLEdBQVIsQ0FBWSxVQUFBQyxHQUFHO0FBQUEsOEJBSXRFLDhEQUFDLHlEQUFEO0FBQUEsc0JBQTBCQSxHQUFHLENBQUNKO0FBQTlCLGFBQWlCSSxHQUFHLENBQUNMLEVBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSnNFO0FBQUEsU0FBZixDQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGQSxtQkFERjtBQW9DQTs7R0F0Q3VCRTtVQUNOakIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50L05hdmJhci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7XHJcbiAgQXBwQmFyLFxyXG4gIFRvb2xiYXIsXHJcbiAgQ3NzQmFzZWxpbmUsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBtYWtlU3R5bGVzLFxyXG59IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgbmF2bGlua3M6IHtcclxuICAgIG1hcmdpbkxlZnQ6IHRoZW1lLnNwYWNpbmcoMTApLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgfSxcclxuIGxvZ286IHtcclxuICAgIGZsZXhHcm93OiBcIjFcIixcclxuICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXHJcbiAgfSxcclxuICBsaW5rOiB7XHJcbiAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXHJcbiAgICBjb2xvcjogXCJ3aGl0ZVwiLFxyXG4gICAgZm9udFNpemU6IFwiMjBweFwiLFxyXG4gICAgbWFyZ2luTGVmdDogdGhlbWUuc3BhY2luZygyMCksXHJcbiAgICBcIiY6aG92ZXJcIjoge1xyXG4gICAgICBjb2xvcjogXCJ5ZWxsb3dcIixcclxuICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCB3aGl0ZVwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5jb25zdCBuYXZMaXN0PVt7aWQ6MSxuYW1lOlwiSG9tZVwifSx7aWQ6MixuYW1lOlwiQWJvdXQgVXNcIn0se2lkOjMsbmFtZTpcIkJ1c2luZXNzIFZlcnRpY2Fsc1wifSx7aWQ6NCxuYW1lOlwiQ29udGFjdCBVc1wifV07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBuYXZiYXIoKSB7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gcmV0dXJuIChcclxuICAgPD5cclxuXHJcbiAgIDxBcHBCYXIgcG9zaXRpb249XCJzdGF0aWNcIj4gIDxDc3NCYXNlbGluZSAvPjxUb29sYmFyPiB7bmF2TGlzdC5tYXAobmF2PT4gKFxyXG5cclxuXHJcblxyXG4gIDxUeXBvZ3JhcGh5IGtleT17bmF2LmlkfT57bmF2Lm5hbWV9PC9UeXBvZ3JhcGh5PlxyXG5cclxuXHJcbikpfSA8L1Rvb2xiYXI+PC9BcHBCYXI+XHJcbiAgey8qIDxOYXZiYXI+ICovfVxyXG4gIHsvKiA8Q29udGFpbmVyPlxyXG4gICAgXHJcbiAgPExpbmsgY2xhc3NOYW1lPVwibmF2YmFyLWJyYW5kXCIgaHJlZj1cIi9cIj48aW1nIGNsYXNzTmFtZT1cIm5hdmJhci1sb2dvXCIgc3JjPVwiL2ltYWdlcy9naXJtZV9sb2dvLnBuZ1wiLz48L0xpbms+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdmJhci1tZW51XCI+ICovfVxyXG4gICAgey8qIDxOYXZiYXIuVG9nZ2xlIGFyaWEtY29udHJvbHM9XCJiYXNpYy1uYXZiYXItbmF2XCIgLz5cclxuICAgIDxOYXZiYXIuQ29sbGFwc2UgaWQ9XCJiYXNpYy1uYXZiYXItbmF2XCI+XHJcbiAgICAgIDxOYXYgY2xhc3NOYW1lPVwibWUtYXV0b1wiPlxyXG4gICAgICAgIDxOYXYuTGluayBocmVmPVwiL1wiPkhvbWU8L05hdi5MaW5rPlxyXG4gICAgICAgIDxOYXYuTGluayBocmVmPVwiL1Byb2R1Y3Rjb250ZW50XCI+UHJvZHVjdHM8L05hdi5MaW5rPlxyXG4gICAgICAgIDxOYXYuTGluayBocmVmPVwiL0Fib3V0dXNjb250ZW50XCI+QWJvdXQgPC9OYXYuTGluaz5cclxuICAgICAgICA8TmF2LkxpbmsgaHJlZj1cIi9JbmZyYXN0cnVjdHVyZWNvbnRlbnRcIj5JbmZyYXN0cnVjdHVyZSA8L05hdi5MaW5rPlxyXG4gICAgICAgIDxOYXYuTGluayBocmVmPVwiL0NvbnRhY3R1c2NvbnRlbnRcIj5Db250YWN0PC9OYXYuTGluaz5cclxuICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIDxOYXYuTGluayBjbGFzc05hbWU9XCJweC00IHB0LTMgZm9vdGVyLWxpc3QtaXRlbVwiIGhyZWY9XCIvZmlsZXMvYnJvY2h1cmUucGRmXCI+PGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUtbGlnaHRcIiB0eXBlPVwic3VibWl0XCI+RG93bmxvYWQgQnJvY2h1cmUgPC9idXR0b24+PC9OYXYuTGluaz5cclxuICAgICAgICAgIFxyXG4gICAgICA8L05hdj5cclxuICAgIDwvTmF2YmFyLkNvbGxhcHNlPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9Db250YWluZXI+XHJcbjwvTmF2YmFyPiAqL31cclxuXHJcbjwvPlxyXG4gKVxyXG59Il0sIm5hbWVzIjpbIkxpbmsiLCJBcHBCYXIiLCJUb29sYmFyIiwiQ3NzQmFzZWxpbmUiLCJUeXBvZ3JhcGh5IiwibWFrZVN0eWxlcyIsInVzZVN0eWxlcyIsInRoZW1lIiwibmF2bGlua3MiLCJtYXJnaW5MZWZ0Iiwic3BhY2luZyIsImRpc3BsYXkiLCJsb2dvIiwiZmxleEdyb3ciLCJjdXJzb3IiLCJsaW5rIiwidGV4dERlY29yYXRpb24iLCJjb2xvciIsImZvbnRTaXplIiwiYm9yZGVyQm90dG9tIiwibmF2TGlzdCIsImlkIiwibmFtZSIsIm5hdmJhciIsImNsYXNzZXMiLCJtYXAiLCJuYXYiXSwic291cmNlUm9vdCI6IiJ9