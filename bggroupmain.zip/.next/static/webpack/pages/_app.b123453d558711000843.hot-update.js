"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./component/Navbar.js":
/*!*****************************!*\
  !*** ./component/Navbar.js ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ navbar; }
/* harmony export */ });
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _excluded = ["children", "value", "index"];

var _jsxFileName = "F:\\BGGroup\\bggroupmain\\component\\Navbar.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.makeStyles)(function (theme) {
  return {
    navlinks: {
      marginLeft: theme.spacing(10),
      display: "flex"
    },
    logo: {
      flexGrow: "1",
      cursor: "pointer"
    },
    link: {
      textDecoration: "none",
      color: "white",
      fontSize: "20px",
      marginLeft: theme.spacing(20),
      "&:hover": {
        color: "yellow",
        borderBottom: "1px solid white"
      }
    }
  };
});
var navList = [{
  id: 1,
  name: "Home"
}, {
  id: 2,
  name: "About Us"
}, {
  id: 3,
  name: "Business Verticals"
}, {
  id: 4,
  name: "Contact Us"
}];
function navbar() {
  _s();

  var classes = useStyles();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_3__.useState(0),
      _React$useState2 = (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_2__.default)(_React$useState, 2),
      value = _React$useState2[0],
      setValue = _React$useState2[1];

  var handleChange = function handleChange(_, newValue) {
    return setValue(newValue);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.CssBaseline, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.AppBar, {
      position: "static",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Toolbar, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
          size: "large",
          edge: "start",
          color: "inherit",
          sx: {
            mr: 2
          },
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.MenuIcon, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Typography, {
          variant: "h6",
          noWrap: true,
          component: "div",
          sx: {
            display: {
              xs: "none",
              sm: "block"
            }
          },
          children: "MUI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Box, {
          flexGrow: 1
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tabs, {
          value: value,
          onChange: handleChange,
          textColor: "inherit",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "One"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "Two"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Tab, {
            label: "Three"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      index: value,
      onChangeIndex: setValue,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 0,
        children: "Item One"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 1,
        children: "Item Two"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(TabPanel, {
        value: value,
        index: 2,
        children: "Item Three"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(navbar, "BDkWVlEh8+DaKPHysXJ2gpEmtFI=", false, function () {
  return [useStyles];
});

function TabPanel(props) {
  var children = props.children,
      value = props.value,
      index = props.index,
      other = (0,F_BGGroup_bggroupmain_node_modules_babel_runtime_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__.default)(props, _excluded);

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", _objectSpread(_objectSpread({
    role: "tabpanel",
    hidden: value !== index
  }, other), {}, {
    children: value === index && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Box, {
      sx: {
        p: 3
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_material_ui_core__WEBPACK_IMPORTED_MODULE_5__.Typography, {
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 9
    }, this)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 85,
    columnNumber: 5
  }, this);
}

_c = TabPanel;

var _c;

$RefreshReg$(_c, "TabPanel");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC5iMTIzNDUzZDU1ODcxMTAwMDg0My5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOzs7QUFhQSxJQUFNVyxTQUFTLEdBQUdELDZEQUFVLENBQUMsVUFBQ0UsS0FBRDtBQUFBLFNBQVk7QUFDdkNDLElBQUFBLFFBQVEsRUFBRTtBQUNSQyxNQUFBQSxVQUFVLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjLEVBQWQsQ0FESjtBQUVSQyxNQUFBQSxPQUFPLEVBQUU7QUFGRCxLQUQ2QjtBQUt4Q0MsSUFBQUEsSUFBSSxFQUFFO0FBQ0hDLE1BQUFBLFFBQVEsRUFBRSxHQURQO0FBRUhDLE1BQUFBLE1BQU0sRUFBRTtBQUZMLEtBTGtDO0FBU3ZDQyxJQUFBQSxJQUFJLEVBQUU7QUFDSkMsTUFBQUEsY0FBYyxFQUFFLE1BRFo7QUFFSkMsTUFBQUEsS0FBSyxFQUFFLE9BRkg7QUFHSkMsTUFBQUEsUUFBUSxFQUFFLE1BSE47QUFJSlQsTUFBQUEsVUFBVSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBYyxFQUFkLENBSlI7QUFLSixpQkFBVztBQUNUTyxRQUFBQSxLQUFLLEVBQUUsUUFERTtBQUVURSxRQUFBQSxZQUFZLEVBQUU7QUFGTDtBQUxQO0FBVGlDLEdBQVo7QUFBQSxDQUFELENBQTVCO0FBcUJBLElBQU1DLE9BQU8sR0FBQyxDQUFDO0FBQUNDLEVBQUFBLEVBQUUsRUFBQyxDQUFKO0FBQU1DLEVBQUFBLElBQUksRUFBQztBQUFYLENBQUQsRUFBb0I7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBcEIsRUFBMkM7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBM0MsRUFBNEU7QUFBQ0QsRUFBQUEsRUFBRSxFQUFDLENBQUo7QUFBTUMsRUFBQUEsSUFBSSxFQUFDO0FBQVgsQ0FBNUUsQ0FBZDtBQUVlLFNBQVNDLE1BQVQsR0FBa0I7QUFBQTs7QUFDL0IsTUFBTUMsT0FBTyxHQUFHbEIsU0FBUyxFQUF6Qjs7QUFDQSx3QkFBMEJYLDJDQUFBLENBQWUsQ0FBZixDQUExQjtBQUFBO0FBQUEsTUFBTytCLEtBQVA7QUFBQSxNQUFjQyxRQUFkOztBQUNBLE1BQU1DLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNDLENBQUQsRUFBSUMsUUFBSjtBQUFBLFdBQWlCSCxRQUFRLENBQUNHLFFBQUQsQ0FBekI7QUFBQSxHQUFyQjs7QUFDRCxzQkFDRTtBQUFBLDRCQUNHLDhEQUFDLDBEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESCxlQUVHLDhEQUFDLHFEQUFEO0FBQVEsY0FBUSxFQUFDLFFBQWpCO0FBQUEsNkJBQ0UsOERBQUMsc0RBQUQ7QUFBQSxnQ0FDRSw4REFBQyx5REFBRDtBQUFZLGNBQUksRUFBQyxPQUFqQjtBQUF5QixjQUFJLEVBQUMsT0FBOUI7QUFBc0MsZUFBSyxFQUFDLFNBQTVDO0FBQXNELFlBQUUsRUFBRTtBQUFFQyxZQUFBQSxFQUFFLEVBQUU7QUFBTixXQUExRDtBQUFBLGlDQUNFLDhEQUFDLHVEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUsOERBQUMseURBQUQ7QUFDRSxpQkFBTyxFQUFDLElBRFY7QUFFRSxnQkFBTSxNQUZSO0FBR0UsbUJBQVMsRUFBQyxLQUhaO0FBSUUsWUFBRSxFQUFFO0FBQUVwQixZQUFBQSxPQUFPLEVBQUU7QUFBRXFCLGNBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNDLGNBQUFBLEVBQUUsRUFBRTtBQUFsQjtBQUFYLFdBSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkYsZUFZRSw4REFBQyxrREFBRDtBQUFLLGtCQUFRLEVBQUU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVpGLGVBYUUsOERBQUMsbURBQUQ7QUFBTSxlQUFLLEVBQUVQLEtBQWI7QUFBb0Isa0JBQVEsRUFBRUUsWUFBOUI7QUFBNEMsbUJBQVMsRUFBQyxTQUF0RDtBQUFBLGtDQUNFLDhEQUFDLGtEQUFEO0FBQUssaUJBQUssRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRSw4REFBQyxrREFBRDtBQUFLLGlCQUFLLEVBQUM7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGLGVBR0UsOERBQUMsa0RBQUQ7QUFBSyxpQkFBSyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZILGVBdUJHO0FBQUssV0FBSyxFQUFFRixLQUFaO0FBQW1CLG1CQUFhLEVBQUVDLFFBQWxDO0FBQUEsOEJBQ0UsOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRUQsS0FBakI7QUFBd0IsYUFBSyxFQUFFLENBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFJRSw4REFBQyxRQUFEO0FBQVUsYUFBSyxFQUFFQSxLQUFqQjtBQUF3QixhQUFLLEVBQUUsQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKRixlQU9FLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVBLEtBQWpCO0FBQXdCLGFBQUssRUFBRSxDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXZCSDtBQUFBLGtCQURGO0FBcUNBOztHQXpDdUJIO1VBQ05qQjs7O0FBMENsQixTQUFTNEIsUUFBVCxDQUFrQkMsS0FBbEIsRUFBeUI7QUFDdkIsTUFBUUMsUUFBUixHQUE2Q0QsS0FBN0MsQ0FBUUMsUUFBUjtBQUFBLE1BQWtCVixLQUFsQixHQUE2Q1MsS0FBN0MsQ0FBa0JULEtBQWxCO0FBQUEsTUFBeUJXLEtBQXpCLEdBQTZDRixLQUE3QyxDQUF5QkUsS0FBekI7QUFBQSxNQUFtQ0MsS0FBbkMsaUlBQTZDSCxLQUE3Qzs7QUFFQSxzQkFDRTtBQUFLLFFBQUksRUFBQyxVQUFWO0FBQXFCLFVBQU0sRUFBRVQsS0FBSyxLQUFLVztBQUF2QyxLQUFrREMsS0FBbEQ7QUFBQSxjQUNHWixLQUFLLEtBQUtXLEtBQVYsaUJBQ0MsOERBQUMsa0RBQUQ7QUFBSyxRQUFFLEVBQUU7QUFBRUUsUUFBQUEsQ0FBQyxFQUFFO0FBQUwsT0FBVDtBQUFBLDZCQUNFLDhEQUFDLHlEQUFEO0FBQUEsa0JBQWFIO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFTRDs7S0FaUUYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50L05hdmJhci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBBcHBCYXIsXHJcbiAgQm94LFxyXG4gIFRvb2xiYXIsXHJcbiAgSWNvbkJ1dHRvbixcclxuICBDc3NCYXNlbGluZSxcclxuICBUeXBvZ3JhcGh5LFxyXG4gIE1lbnVJY29uLFxyXG4gIFRhYnMsXHJcbiAgVGFiLFxyXG4gIG1ha2VTdHlsZXMsXHJcbn0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICBuYXZsaW5rczoge1xyXG4gICAgbWFyZ2luTGVmdDogdGhlbWUuc3BhY2luZygxMCksXHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICB9LFxyXG4gbG9nbzoge1xyXG4gICAgZmxleEdyb3c6IFwiMVwiLFxyXG4gICAgY3Vyc29yOiBcInBvaW50ZXJcIixcclxuICB9LFxyXG4gIGxpbms6IHtcclxuICAgIHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIixcclxuICAgIGNvbG9yOiBcIndoaXRlXCIsXHJcbiAgICBmb250U2l6ZTogXCIyMHB4XCIsXHJcbiAgICBtYXJnaW5MZWZ0OiB0aGVtZS5zcGFjaW5nKDIwKSxcclxuICAgIFwiJjpob3ZlclwiOiB7XHJcbiAgICAgIGNvbG9yOiBcInllbGxvd1wiLFxyXG4gICAgICBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkIHdoaXRlXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmNvbnN0IG5hdkxpc3Q9W3tpZDoxLG5hbWU6XCJIb21lXCJ9LHtpZDoyLG5hbWU6XCJBYm91dCBVc1wifSx7aWQ6MyxuYW1lOlwiQnVzaW5lc3MgVmVydGljYWxzXCJ9LHtpZDo0LG5hbWU6XCJDb250YWN0IFVzXCJ9XTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIG5hdmJhcigpIHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZSgwKTtcclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoXywgbmV3VmFsdWUpID0+IHNldFZhbHVlKG5ld1ZhbHVlKTtcclxuIHJldHVybiAoXHJcbiAgIDw+XHJcbiAgICAgIDxDc3NCYXNlbGluZSAvPlxyXG4gICAgICA8QXBwQmFyIHBvc2l0aW9uPVwic3RhdGljXCI+XHJcbiAgICAgICAgPFRvb2xiYXI+XHJcbiAgICAgICAgICA8SWNvbkJ1dHRvbiBzaXplPVwibGFyZ2VcIiBlZGdlPVwic3RhcnRcIiBjb2xvcj1cImluaGVyaXRcIiBzeD17eyBtcjogMiB9fT5cclxuICAgICAgICAgICAgPE1lbnVJY29uIC8+XHJcbiAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICB2YXJpYW50PVwiaDZcIlxyXG4gICAgICAgICAgICBub1dyYXBcclxuICAgICAgICAgICAgY29tcG9uZW50PVwiZGl2XCJcclxuICAgICAgICAgICAgc3g9e3sgZGlzcGxheTogeyB4czogXCJub25lXCIsIHNtOiBcImJsb2NrXCIgfSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBNVUlcclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDxCb3ggZmxleEdyb3c9ezF9IC8+XHJcbiAgICAgICAgICA8VGFicyB2YWx1ZT17dmFsdWV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IHRleHRDb2xvcj1cImluaGVyaXRcIj5cclxuICAgICAgICAgICAgPFRhYiBsYWJlbD1cIk9uZVwiIC8+XHJcbiAgICAgICAgICAgIDxUYWIgbGFiZWw9XCJUd29cIiAvPlxyXG4gICAgICAgICAgICA8VGFiIGxhYmVsPVwiVGhyZWVcIiAvPlxyXG4gICAgICAgICAgPC9UYWJzPlxyXG4gICAgICAgIDwvVG9vbGJhcj5cclxuICAgICAgPC9BcHBCYXI+XHJcbiAgICAgIDxkaXYgaW5kZXg9e3ZhbHVlfSBvbkNoYW5nZUluZGV4PXtzZXRWYWx1ZX0+XHJcbiAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezB9PlxyXG4gICAgICAgICAgSXRlbSBPbmVcclxuICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXsxfT5cclxuICAgICAgICAgIEl0ZW0gVHdvXHJcbiAgICAgICAgPC9UYWJQYW5lbD5cclxuICAgICAgICA8VGFiUGFuZWwgdmFsdWU9e3ZhbHVlfSBpbmRleD17Mn0+XHJcbiAgICAgICAgICBJdGVtIFRocmVlXHJcbiAgICAgICAgPC9UYWJQYW5lbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBUYWJQYW5lbChwcm9wcykge1xyXG4gIGNvbnN0IHsgY2hpbGRyZW4sIHZhbHVlLCBpbmRleCwgLi4ub3RoZXIgfSA9IHByb3BzO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiByb2xlPVwidGFicGFuZWxcIiBoaWRkZW49e3ZhbHVlICE9PSBpbmRleH0gey4uLm90aGVyfT5cclxuICAgICAge3ZhbHVlID09PSBpbmRleCAmJiAoXHJcbiAgICAgICAgPEJveCBzeD17eyBwOiAzIH19PlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHk+e2NoaWxkcmVufTwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8L0JveD5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gKVxyXG59Il0sIm5hbWVzIjpbIlJlYWN0IiwiQXBwQmFyIiwiQm94IiwiVG9vbGJhciIsIkljb25CdXR0b24iLCJDc3NCYXNlbGluZSIsIlR5cG9ncmFwaHkiLCJNZW51SWNvbiIsIlRhYnMiLCJUYWIiLCJtYWtlU3R5bGVzIiwidXNlU3R5bGVzIiwidGhlbWUiLCJuYXZsaW5rcyIsIm1hcmdpbkxlZnQiLCJzcGFjaW5nIiwiZGlzcGxheSIsImxvZ28iLCJmbGV4R3JvdyIsImN1cnNvciIsImxpbmsiLCJ0ZXh0RGVjb3JhdGlvbiIsImNvbG9yIiwiZm9udFNpemUiLCJib3JkZXJCb3R0b20iLCJuYXZMaXN0IiwiaWQiLCJuYW1lIiwibmF2YmFyIiwiY2xhc3NlcyIsInVzZVN0YXRlIiwidmFsdWUiLCJzZXRWYWx1ZSIsImhhbmRsZUNoYW5nZSIsIl8iLCJuZXdWYWx1ZSIsIm1yIiwieHMiLCJzbSIsIlRhYlBhbmVsIiwicHJvcHMiLCJjaGlsZHJlbiIsImluZGV4Iiwib3RoZXIiLCJwIl0sInNvdXJjZVJvb3QiOiIifQ==